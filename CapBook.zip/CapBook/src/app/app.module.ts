import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './shared/list/list.component';
import { HomepageComponent } from './homepage/homepage.component';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TimelineComponent } from './timeline/timeline.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { AuthGuard } from './Authguard/auth.guard';
import { UseraccountService } from './Services/useraccount.service';
import {HttpClientModule} from '@angular/common/http';
import { PersonaldetailsComponent } from './personaldetails/personaldetails.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';
import { PhotosComponent } from './photos/photos.component'


@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    HomepageComponent,
    TimelineComponent,
    RegistrationComponent,
    WelcomeComponent,
    PersonaldetailsComponent,
    ChangepasswordComponent,
    DeleteaccountComponent,
    PhotosComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'photosComponent',component:PhotosComponent},
      {path:'deleteaccountComponent',component:DeleteaccountComponent},
      {path:'changepasswordComponent',component:ChangepasswordComponent},
      {path:'personaldetailsComponent',component:PersonaldetailsComponent},
      {path:'timelineComponent',component:TimelineComponent,canActivate:[AuthGuard]},
      {path:'registrationComponent',component:RegistrationComponent},
      {path:'homepageComponent',component:HomepageComponent,canActivate:[AuthGuard]},
      {path:'welcomeComponent',component: WelcomeComponent},
      {path:'',redirectTo:'welcomeComponent',pathMatch:'full'},
    ]),
  ],
  providers: [AuthGuard,UseraccountService],
  bootstrap: [AppComponent]
})
export class AppModule { }
