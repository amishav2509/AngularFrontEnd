import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserAccount } from '../UserInterface/user-account';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  _password:string;
  userAccountDetails:UserAccount;
  newPassword:string;
  confirmNewPasswordPassword:string;
  message:string;
  get password():string{
    return this._password;
  } 
  set password(value: string){
    this._password = value;
  }

  constructor(private router: Router) { }

  ngOnInit() { 
  }
  back(): void {
    console.log("back");
    this.router.navigate(['/timelineComponent']);
  }
  changePassword(): void {
    
  }

}
