import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListComponent } from './shared/list/list.component';
import { HomepageComponent } from './homepage/homepage.component';
import {FormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TimelineComponent } from './timeline/timeline.component';
import { RegistrationComponent } from './registration/registration.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { SearchComponent } from './shared/search/search.component';



@NgModule({
  declarations: [
    AppComponent,
    ListComponent,
    HomepageComponent,
    TimelineComponent,
    RegistrationComponent,
    WelcomeComponent,
    SearchComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'timelineComponent',component:TimelineComponent},
      {path:'registrationComponent',component:RegistrationComponent},
      {path:'homepageComponent',component:HomepageComponent},
      {path:'welcomeComponent',component: WelcomeComponent},
      {path:'',redirectTo:'welcomeComponent',pathMatch:'full'},
    ]),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
